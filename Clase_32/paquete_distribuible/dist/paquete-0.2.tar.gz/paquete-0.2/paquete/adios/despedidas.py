def despedir():
    print("Adiós, me estoy despidiendo desde la función despedir() " \
            "del módulo despedidas")

class Despedida():
    def __init__(self):
        print("Adiós, me estoy despidiendo desde el __init__ " \
                "de la clase Despedida")